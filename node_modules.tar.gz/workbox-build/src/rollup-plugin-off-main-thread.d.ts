declare module '@surma/rollup-plugin-off-main-thread';
